let nave
let municion;

function setup() {
    createCanvas(900, 600);
    nave = new Nave(450, 550, 60);
    municion = [];
}

function draw() {
    background(0);

    for (let i = 0; i < municion.length; i++) {
        const bala = municion[i];
        bala.crearBala();
        if (bala.posY < -100) {
            municion.splice(1, i);
        }
    }

    nave.dibujarNave();

}

function keyPressed() {
    if (keyCode == RIGHT_ARROW && nave.posX < 850) {
        nave.posX += 100;
    }

    if (keyCode == LEFT_ARROW && nave.posX > 50) {
        nave.posX -= 100;
    }

    if (keyCode == 32) {
        municion.push(new Bala(nave.posX, nave.posY, 10, 10));
    }

    print(keyCode);
}
