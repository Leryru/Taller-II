class Enemigo {
    constructor(posX, posY, tamX, tamY, r, g, b, resistencia) {
        this.posX = posX;
        this.posY = posY;
        this.tamX = tamX;
        this.tamY = tamY;
        this.r = r;
        this.g = g;
        this.b = b;
        this.resistencia = resistencia;
    }
}
