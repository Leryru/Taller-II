class Nave {
    constructor(posX, posY, tam) {
        this.posX = posX;
        this.posY = posY;
        this.tam = tam;
    }

    dibujarNave() {
        rectMode(CENTER);
        ellipse(this.posX, this.posY, this.tam, this.tam);
        fill(255);
    }
}