class Bala {
    constructor(posX, posY, tam) {
        this.posX = posX;
        this.posY = posY;
        this.tam = tam;
        this.vel = -5;
    }
    crearBala() {
        fill(255);
        ellipse(this.posX, this.posY += this.vel, this.tam, this.tam);
    }
}