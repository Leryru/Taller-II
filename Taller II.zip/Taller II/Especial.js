class Especial extends Enemigo {
    super(posX, posY, ancho, alto, r, g, b, resistencia) {

    }
}