class Basico extends Enemigo{
    super(posX, posY, ancho, alto, r, g, b, resistencia){
        
    }
}